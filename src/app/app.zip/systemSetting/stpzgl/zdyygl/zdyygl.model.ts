export class ZdyyglModel {
    id: string;
    bm: string;
    zdm: string;
    sslbId: string;
}