export class ProjectType {
    id: string;
    name: string;
    shortName: string;
    code: string;
    projectDesc: string;
    orderNumber: number;
    projectTypeCode: string;
    remark: string;
    creatTime: string;
}