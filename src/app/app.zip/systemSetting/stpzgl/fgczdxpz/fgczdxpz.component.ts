import {Component, OnInit, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';
import {FgczdxpzxqComponent} from "./fgczdxpzxq.component";
import {HttpService} from "../../../service/http-service";
import {flyIn} from "../../../animations/fly-in";

@Component({
    selector: 'app-fgczdxpz',
    templateUrl: './fgczdxpz.component.html',
    styleUrls: ['./fgczdxpz.component.css'],
    providers: [HttpService],
    animations: [flyIn]
})
export class FgczdxpzComponent implements OnInit {
    private cars: any;
    private gcUrl = 'gczc/allList';

    constructor(private HttpService: HttpService, private AlertModel: ComponentFactoryResolver) {
    }

    @ViewChild('pdialog', {read: ViewContainerRef}) AlertBox: ViewContainerRef;

    ngOnInit() {
        this.HttpService.get('xtfqhzdx/list')
            .then(res => {
                console.log(res['returnObject']);
                this.cars = res['returnObject'];
            })
    }

    addAlert() {

        let alert = this.AlertModel.resolveComponentFactory(FgczdxpzxqComponent);
        this.AlertBox.createComponent(alert);
    }

    onRowSelect(i){
        console.log(i);
    }

    getProjectId(i) {
        console.log(i);
    }

}
