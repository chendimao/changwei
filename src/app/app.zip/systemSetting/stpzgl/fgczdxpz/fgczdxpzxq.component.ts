import {Component, OnInit} from '@angular/core';


@Component({
    selector: 'app-fgczdxpzxq',
    templateUrl: './fgczdxpzxq.component.html',
    styleUrls: ['./fgczdxpz.component.css']
})
export class FgczdxpzxqComponent implements OnInit {
    private display: boolean = true;
    private TreeTable: any;
    private filesTree: any;
    selectedFile: any;
    private showTable:number=0;
    constructor() {
    }



    ngOnInit() {
        this.TreeTable = [
            {
                "data": {
                    "name": "水库淹没影响区",
                    "code": "A1",
                    "bz": ""
                },
                "children": [
                    {
                        "data": {
                            "name": "淹没区",
                            "code": "A1",
                            "bz": ""
                        },
                        "children": [
                            {
                                "data": {
                                    "name": "围堰水位及以下",
                                    "code": "A1",
                                    "bz": ""
                                }
                            },
                            {
                                "data": {
                                    "name": "围堰水位以上",
                                    "code": "A1",
                                    "bz": ""
                                }
                            }
                        ]
                    },
                    {
                        "data": {
                            "name": "Home",
                            "code": "A1",
                            "bz": ""
                        },
                        "children": [
                            {
                                "data": {
                                    "name": "Invoices",
                                    "size": "20kb",
                                    "type": "Text"
                                }
                            }
                        ]
                    }
                ]
            },
            {
                "data": {
                    "name": "Pictures",
                    "size": "150kb",
                    "type": "Folder"
                },
                "children": [
                    {
                        "data": {
                            "name": "barcelona.jpg",
                            "size": "90kb",
                            "type": "Picture"
                        }
                    },
                    {
                        "data": {
                            "name": "primeui.png",
                            "size": "30kb",
                            "type": "Picture"
                        }
                    },
                    {
                        "data": {
                            "name": "optimus.jpg",
                            "size": "30kb",
                            "type": "Picture"
                        }
                    }
                ]
            }
        ];
        this.filesTree = [
            {
                "label": "建设征地范围",
                "children": [{
                    "label": "云南省",
                    "data": "yunan",
                    "children": [
                        {"label": "楚雄州", "data": "Expenses Document"},
                        {
                            "label": "武定县",
                            "data": "Resume Document",
                            "children": [
                                {
                                    "label": "XXX乡",
                                    'data': "xxx"
                                }
                            ]
                        }
                    ]
                },
                    {
                        "label": "四川省",
                        "data": "Home Folder",

                    }]
            },

        ];
    }

    close() {
        this.display = false;
    }

    showList(i) {
        switch (i){
            case 1:
                if(this.showTable==1){
                    this.showTable=0;
                }else{
                    this.showTable=1;
                }
                break;

            case 2:
                if(this.showTable==2){
                    this.showTable=0;
                }else{
                    this.showTable=2;
                }
            break;
        }
    }

    nodeSelect(e) {
        console.log(e);
        console.log(e['data']);
    }

}
