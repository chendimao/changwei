import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {DataProcessingService} from "../../../service/dataProcessing.service";
import {HttpService} from "../../../service/http-service";
import {DelWaringComponent} from "../../../common/del-waring/del-waring.component";

@Component({
    selector: 'app-swzbflpzxq',
    templateUrl: './swzbflpzxq.component.html',
    styleUrls: ['../swzbtxpz/swzbtxpz.component.css'],
})
export class SwzbflpzxqComponent implements OnInit {
    display: boolean = true;
    public info = {};
    public type: string;
    private zbdm: string;
    private isDisabled: boolean = false;
    private node: any;
    private addObj: any;

    private sourceTreeTable: any;
    private initSourceTreeTable: any;
    private isSourceShow1: boolean = true;
    private isSourceShow2: boolean = true;
    private targetTreeTable: any;
    private initTargetTreeTable: any;
    selectedFiles: any;

    private jldwList: any;
    private jldw: any;
    private ssfllbList: any;
    private zbflList: any;
    private flhList = new Array;
    private msgs: any;

    list1: any;
    list2: any;
    @ViewChild('alterRoom', {read: ViewContainerRef}) AlertBox: ViewContainerRef;

    constructor(private dmRoom: ComponentFactoryResolver, private DataProcessingService: DataProcessingService, private HttpService: HttpService) {
    }

    ngOnInit() {
        console.log(this.info);
        console.log(this.type);
        if (this.type == 'view') {
            this.isDisabled = true;
        } else {
            this.isDisabled = false;
        }
        this.zbdm = this.info['zbldm'];
        this.HttpService.get('zbflpz/listFllb')
            .then(res => {
                this.ssfllbList = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'mc', 'label', 'sjlb', 'value');
            });

        this.HttpService.get('zbflpz/listZbfl?zdlb=ZBL')
            .then(res => {
                this.zbflList = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'mc', 'label', 'sjlb', 'value');
            });

        this.HttpService.get(`zbflpz/listSjly?ssgcdm=${this.info['ssgcdm']}&ssxzqhdm=${this.info['ssxzqhdm']}&zblId=${this.info['zblId']}&jdId=${this.info['jdId']}`)
            .then(res => {
                const resList = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'childList', 'children', '', '');
                this.sourceTreeTable = this.DataProcessingService.replaceisCheck(this.DataProcessingService.returnTreeTable(resList));
                const initreslist = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'childList', 'children', '', '');
                this.initSourceTreeTable = this.DataProcessingService.replaceisCheck(this.DataProcessingService.returnTreeTable(initreslist));
                console.log(this.sourceTreeTable);
            });

        this.HttpService.get(`zbflpz/listFlzbxpz?sszbflpzId=${this.info['id']}`)
            .then(res => {
                const resList = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'childList', 'children', '', '');
                this.targetTreeTable = this.DataProcessingService.replaceisCheck(this.DataProcessingService.returnTreeTable(resList));
                const initreslist = this.DataProcessingService.replaceChildlValue(res['returnObject'], 'childList', 'children', '', '');
                this.initTargetTreeTable = this.DataProcessingService.replaceisCheck(this.DataProcessingService.returnTreeTable(initreslist));
            });

        this.HttpService.get('xtswzbfl/listJldw')
            .then(res => {
                this.jldwList = res['returnObject'];
                this.jldw = res['returnObject'][0].id;
            });

        this.addObj = {
            "ssgcdm": this.info['ssgcdm'], //所属工程代码（必填）
            "ssxzqhdm": this.info['ssxzqhdm'], //所属行政区划代码（必填）
            "jdId": this.info['jdId'], //阶段ID（必填）
            "zblId": this.info['zblId'], //指标类ID（必填）
            "ssfllbdm": this.info['ssfllbdm'], //所属分栏类别ID（必填）
            "ssflh": this.info['ssflh'], //分栏号
            "bz": this.info['bz'], //备注
        };


        this.flhList = [
            {label: '第一栏', value: '1', name: '第一栏'},
            {label: '第一栏', value: '2', name: '第二栏'},
            {label: '第一栏', value: '3', name: '第三栏'},
            {label: '第一栏', value: '4', name: '第四栏'},
        ];
        this.list1 = [
            {brand: '1', year: '222', color: '222'},
            {brand: '2', year: '222', color: '222'},
            {brand: '3', year: '222', color: '222'},
            {brand: '4', year: '222', color: '222'}
        ];
        this.list2 = [
            {brand: '5', year: '222', color: '222'},
            {brand: '6', year: '222', color: '222'},
            {brand: '7', year: '222', color: '222'},
            {brand: '8', year: '222', color: '222'}
        ];
    }

    close() {
        this.display = false;
    }


    isShowSource(i) {
        if (this.isSourceShow1) {
            this.isSourceShow1 = false;
        } else {
            this.isSourceShow1 = true;
        }
        switch (i) {
            case 1:
                this.sourceTreeTable = this.DataProcessingService.showCheck(this.sourceTreeTable, 0);
                console.log("显示非空项");
                break;
            case 2:
                this.sourceTreeTable = JSON.parse(JSON.stringify(this.initSourceTreeTable));
                console.log("显示所有项");
                break;
        }
    }

    selectSourceAll(i) {
        console.log(this.sourceTreeTable);
        console.log(this.initSourceTreeTable);
        if (this.isSourceShow2) {
            this.isSourceShow2 = false;
        } else {
            this.isSourceShow2 = true;
        }
        switch (i) {
            case 1:

                this.sourceTreeTable = this.DataProcessingService.checkAll(this.sourceTreeTable);
                console.log("全选");
                break;
            case 2:
                this.initSourceTreeTable = JSON.parse(JSON.stringify(this.initSourceTreeTable));
                console.log("取消全选");
                break;
        }
    }


    nodeSelect(e) {
        console.log(e);

    }

    nodeUnselect(e) {
        console.log(e);
        console.log(this.selectedFiles);
    }

    checkbox(e, res) {
        // if (res) {
        //     e.data.isCheck = 1;
        //     console.log(res);
        //     if (e.parent) {
        //         e.parent.data.isCheck = 1;
        //     } else {
        //         for (var i = 0; i < e.children.length; i++) {
        //             e.children[i].data.isCheck = 1;
        //         }
        //     }
        // } else {
        //     if (typeof(e.parent) == 'undefined') {
        //         for (var i = 0; i < e.children.length; i++) {
        //             e.children[i].data.isCheck = 0;
        //         }
        //     }
        // }
        this.node = e;
        console.log(this.node);
        console.log(res);
    }

    addSelectParentNode(e) {
        console.log(this.node.parent);
        if (this.node.parent) {
            console.log("选择了子节点");
            this.msgs = [];
            this.msgs.push({severity: 'error', summary: '填入提醒', detail: '请选择根节点项'});
        } else {
            console.log(this.addObj);
            console.log(this.node);
            this.addObj['zbxpzList'] = [];
            this.addObj['zbxpzList'].push(this.node.data);
            console.log(this.addObj);
            console.log("增加根节点");
            this.HttpService.post('/zbflpz/add', this.addObj)
                .then(res => {
                    console.log(res);
                })
        }

    }

    addSelectChildrenNode(e) {
        console.log(this.node.parent);
        if (this.node.parent) {
            console.log("选择了子节点");
            console.log(this.addObj);
            console.log(this.node);
            this.addObj['zbxpzList'] = [];
            this.addObj['zbxpzList'].push(this.node.data);
            console.log(this.addObj);
            console.log("增加根节点");
            this.HttpService.post('/zbflpz/add', this.addObj)
                .then(res => {
                    console.log(res);

                })
        } else {
            this.msgs = [];
            this.msgs.push({severity: 'error', summary: '填入提醒', detail: '请选择子节点项'});
        }
    }

    addSelectSibNode(e) {
        console.log(e);
    }

    addNode(e) {


        console.log(e);
    }


    addChildrenNode(e) {
        console.log(e);
    }

    addSibNode(e) {
        console.log(e);
    }

    delNode(e) {
        console.log(this.node);
        console.log("删除所选项");
        this.AlertBox.clear();
        if (this.node.data['id'] == null) {
            this.msgs = [];
            this.msgs.push({severity: 'error', summary: '填入提醒', detail: '请选择删除项'});
        } else {
            const delmodel = this.dmRoom.resolveComponentFactory(DelWaringComponent);
            const delModelbxo = this.AlertBox.createComponent(delmodel);
            delModelbxo.instance.message = "删除当前选择项(删除后数据无法恢复)";
            delModelbxo.instance.url = 'zbflpz/delete?id=' + this.node.data['id'];
            delModelbxo.instance.confirm();
        }
    }

    getjSourcelList(e) {
        console.log(e);
    }

    getjlTargetList(e) {
        console.log(e);

    }

    getSsfllb(e) {
        console.log(e);
    }

    getZbfllb(e) {
        console.log(e);
    }

    getFlh(e) {
        console.log(e);
    }


}
