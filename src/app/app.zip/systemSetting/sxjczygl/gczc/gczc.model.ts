export class GczcModel {
    name: string;
    shortName: string;
    code: string;
    projectDesc: string;
    projectTypeCode: string;
    orderNumber: string;
    remark: string;
}