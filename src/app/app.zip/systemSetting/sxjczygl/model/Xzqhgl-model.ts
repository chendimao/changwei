export class XzqhglModel {
    "orderType": string;//orderType
    "orderCol": string;//orderCol
    "subLocalityExpression": string;//下级区划代码表达式
    "start": string;//起始记录
    "localityCode": string;//区划代码
    "remark": string;//备注
    "searchKey": string;//搜索字符
    "childrenLocality": string;//childrenLocality
    "localityDesc": string;//区划全称
    "sql": string;//sql
    "localityName": string;//区划简称
    "limit": string;//每页条数
    "localityLevel": string;//区划级别
    "parentLocCode": string;//父区划代码
    "id": string;//
}