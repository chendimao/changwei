import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NjgcymazqqgzjdComponent } from './njgcymazqqgzjd.component';

describe('NjgcymazqqgzjdComponent', () => {
  let component: NjgcymazqqgzjdComponent;
  let fixture: ComponentFixture<NjgcymazqqgzjdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NjgcymazqqgzjdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NjgcymazqqgzjdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
