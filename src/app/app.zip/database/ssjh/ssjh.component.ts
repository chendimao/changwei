import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ssjh',
  templateUrl: './ssjh.component.html',
  styleUrls: ['./ssjh.component.css']
})
export class SsjhComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
