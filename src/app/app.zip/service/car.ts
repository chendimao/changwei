export interface Car {
    year;
    brand;
    color;
}

