export interface Popup {
  content: string;
  callback: () => void;
}
