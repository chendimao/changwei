import { Component } from '@angular/core';


@Component({
    selector: 'app-kxxyjbgjd',
    template: '<router-outlet></router-outlet>',
})
export class SsjdComponent{
}
