import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gyqycl',
  templateUrl: './gyqycl.component.html',
  styleUrls: ['./gyqycl.component.css']
})
export class GyqyclComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
