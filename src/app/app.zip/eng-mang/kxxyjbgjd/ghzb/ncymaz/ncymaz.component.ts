import {Component} from '@angular/core';


@Component({
    selector: 'app-ncymaz',
    template: '<router-outlet></router-outlet>',
})
export class NcymazComponent {
}
