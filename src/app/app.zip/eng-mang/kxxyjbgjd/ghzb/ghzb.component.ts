import {Component} from '@angular/core';


@Component({
    selector: 'app-ghzb',
    template: '<router-outlet></router-outlet>',
})
export class GhzbComponent {
}
