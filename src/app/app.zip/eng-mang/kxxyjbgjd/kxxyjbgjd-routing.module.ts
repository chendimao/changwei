

export const KxxyjbgjdRoutingModule = [
     {
        path: 'swzb/:item',
        loadChildren: './swzb/swzb.module#SwzbModule',
    }
]