import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sbdgcjbxx',
  templateUrl: './sbdgcjbxx.component.html',
    styleUrls: ['../children.css']
})
export class SbdgcjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
