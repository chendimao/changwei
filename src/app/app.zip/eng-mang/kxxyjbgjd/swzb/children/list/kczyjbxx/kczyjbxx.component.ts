import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kczyjbxx',
  templateUrl: './kczyjbxx.component.html',
    styleUrls: ['../children.css']
})
export class KczyjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
