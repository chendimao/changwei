import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gbdsjbxx',
  templateUrl: './gbdsjbxx.component.html',
    styleUrls: ['../children.css']
})
export class GbdsjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
