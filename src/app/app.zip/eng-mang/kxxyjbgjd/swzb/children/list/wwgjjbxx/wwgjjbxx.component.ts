import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wwgjjbxx',
  templateUrl: './wwgjjbxx.component.html',
    styleUrls: ['../children.css']
})
export class WwgjjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
