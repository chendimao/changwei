import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gkjbxx',
  templateUrl: './gkjbxx.component.html',
    styleUrls: ['../children.css']
})
export class GkjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
