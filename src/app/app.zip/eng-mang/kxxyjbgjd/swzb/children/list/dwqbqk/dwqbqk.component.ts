import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dwqbqk',
  templateUrl: './dwqbqk.component.html',
    styleUrls: ['../children.css']
})
export class DwqbqkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
