import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slsdgcjbxx',
  templateUrl: './slsdgcjbxx.component.html',
    styleUrls: ['../children.css']
})
export class SlsdgcjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
