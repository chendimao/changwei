import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tljbxx',
  templateUrl: './tljbxx.component.html',
    styleUrls: ['../children.css']
})
export class TljbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
