import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jtgsjbxq',
  templateUrl: './jtgsjbxq.component.html',
    styleUrls: ['../children.css']
})
export class JtgsjbxqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
