import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gykqyxq',
  templateUrl: './gykqyxq.component.html',
    styleUrls: ['../children.css']
})
export class GykqyxqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
