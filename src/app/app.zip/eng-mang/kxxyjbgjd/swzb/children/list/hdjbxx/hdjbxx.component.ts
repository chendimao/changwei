import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hdjbxx',
  templateUrl: './hdjbxx.component.html',
    styleUrls: ['../children.css']
})
export class HdjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
