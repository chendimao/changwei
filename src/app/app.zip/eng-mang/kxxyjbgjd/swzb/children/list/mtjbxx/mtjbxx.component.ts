import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mtjbxx',
  templateUrl: './mtjbxx.component.html',
    styleUrls: ['../children.css']
})
export class MtjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
