import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gdgcjbxx',
  templateUrl: './gdgcjbxx.component.html',
    styleUrls: ['../children.css']
})
export class GdgcjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
