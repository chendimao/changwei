import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-swqxzjbxx',
  templateUrl: './swqxzjbxx.component.html',
    styleUrls: ['../children.css']
})
export class SwqxzjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
