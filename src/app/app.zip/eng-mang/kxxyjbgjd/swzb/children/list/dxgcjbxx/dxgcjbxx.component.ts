import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dxgcjbxx',
  templateUrl: './dxgcjbxx.component.html',
    styleUrls: ['../children.css']
})
export class DxgcjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
