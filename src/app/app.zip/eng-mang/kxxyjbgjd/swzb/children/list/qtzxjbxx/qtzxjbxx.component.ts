import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qtzxjbxx',
  templateUrl: './qtzxjbxx.component.html',
    styleUrls: ['../children.css']
})
export class QtzxjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
