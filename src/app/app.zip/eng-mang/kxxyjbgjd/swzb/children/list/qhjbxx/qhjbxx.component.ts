import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qhjbxx',
  templateUrl: './qhjbxx.component.html',
    styleUrls: ['../children.css']
})
export class QhjbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
