import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gljbxx',
  templateUrl: './gljbxx.component.html',
    styleUrls: ['../children.css']
})
export class GljbxxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
