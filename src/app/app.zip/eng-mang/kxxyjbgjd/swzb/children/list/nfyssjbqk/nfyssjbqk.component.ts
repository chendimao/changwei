import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nfyssjbqk',
  templateUrl: './nfyssjbqk.component.html',
    styleUrls: ['../children.css']
})
export class NfyssjbqkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
