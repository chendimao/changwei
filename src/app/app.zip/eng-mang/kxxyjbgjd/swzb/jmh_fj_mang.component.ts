import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {JmhfjmangsecComponent} from "./jmh_fj_mangsec.component";

@Component({
    selector: 'app-jmhfjmang',
    templateUrl: './jmh_fj_mang.component.html',
    styleUrls: ['./jmh.component.css']
})
export class JmhMangComponent implements OnInit {
    private data: String = "";
    display: boolean = true;


    @ViewChild('model', {read: ViewContainerRef}) modelBox: ViewContainerRef;

    constructor(private comAlert: ComponentFactoryResolver) {
    }

    ngOnInit() {
    }

    close() {
        this.display = false;
    }

    getSelect(value) {
        console.log(value);
    }

    openModal() {
        console.log(111);
        const com = this.comAlert.resolveComponentFactory(JmhfjmangsecComponent);
        console.log(com);
        console.log(this.modelBox);
        this.modelBox.createComponent(com);
    }
}
