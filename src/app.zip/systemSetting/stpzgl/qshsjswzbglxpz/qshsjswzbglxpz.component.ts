import {Component, OnInit} from '@angular/core';
import {HttpService} from "../../../service/http-service";

@Component({
    selector: 'app-qshsjswzbglxpz',
    templateUrl: './qshsjswzbglxpz.component.html',
    styleUrls: ['../swzbtxpz/swzbtxpz.component.css'],
    providers: [HttpService]
})
export class QshsjswzbglxpzComponent implements OnInit {
    showBlock: boolean = false;
    private gcList = [{}];
    private jdList = [{}];
    private qshlbUrl: any;
    private qshGetParme = new qshGetParme;

    constructor(private HttpService: HttpService) {
    }

    ngOnInit() {
        this.qshlbUrl = 'qsrsjswzb/listQsrlb';
        this.HttpService.get('gczc/allList')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/name/g, 'label');
                list = list.replace(/code/g, "value");
                this.gcList = JSON.parse(list);
                console.log(this.gcList);
            });

        this.HttpService.get('xtswzbfl/listGzjd')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/mc/g, 'label');
                list = list.replace(/id/g, "value");
                this.jdList = JSON.parse(list);
                console.log(this.jdList);
            });


    }

    getGzjdId(e) {
        console.log(e);
    }

    getProjectId(e) {
        console.log(e);
        this.qshGetParme.ssgcdm = e;
    }

    getAreaCode(e) {
        console.log(e);
        this.qshGetParme.ssxzqhdm = e.localityCode;
    }

    getQsrlxzdxId(e) {
        console.log(e);
        console.log(e.id);
        this.qshGetParme.qsrlxzdxId = e.id;
    }

    showGclist() {
        if (this.showBlock == true) {
            this.showBlock = false;
        } else {
            this.showBlock = true;
        }
    }
}

export class qshGetParme {
    ssgcdm: string	    //所属工程代码	是
    ssxzqhdm: string	//所属行政区划代码	是
    qsrlxzdxId: string	//权属人类别ID	是
    searchKey: string	//用于搜索匹配名称	否
}

