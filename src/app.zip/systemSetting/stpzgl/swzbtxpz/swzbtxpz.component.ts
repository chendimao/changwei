import {Component, OnInit, DoCheck} from '@angular/core';
import {HttpService} from "../../../service/http-service";
import {DataProcessingService} from "../../../service/dataProcessing.service";

@Component({
    selector: 'app-swzbtxpz',
    templateUrl: './swzbtxpz.component.html',
    styleUrls: ['./swzbtxpz.component.css'],
})
export class SwzbtxpzComponent implements OnInit {
    showBlock: boolean = false;
    private msgs = new Array;
    private gcList = [{}];
    private jdList = [{}];
    private zbflUrl: any;
    private swzbtxpzGetParme = new swzbtxpzGetParme;
    private TreeTable = new Array;


    constructor(private HttpService: HttpService, private DataProcessingService: DataProcessingService) {
    }

    ngOnInit() {
        //指标分类
        this.zbflUrl = 'xtswzbfl/listZbfl?zdlb=ZBL';
        this.HttpService.get('gczc/allList')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/name/g, 'label');
                list = list.replace(/code/g, "value");
                this.gcList = JSON.parse(list);
                console.log(this.gcList);
            });

        this.HttpService.get('xtswzbfl/listGzjd')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/mc/g, 'label');
                list = list.replace(/id/g, "value");
                this.jdList = JSON.parse(list);
                console.log(this.jdList);
            });

    }


    getList() {
        console.log(this.swzbtxpzGetParme);
        var arr = [];
        for (var key in this.swzbtxpzGetParme) {
            var str = key + "=" + this.swzbtxpzGetParme[key];
            arr.push(str);
        }
        var params = arr.join("&");
        if (this.swzbtxpzGetParme.ssxzqhdm == null) {
            this.msgs = [];
            this.msgs.push({severity: 'error', summary: '参数缺少', detail: '请选择行政区划代码'});
        } else if (this.swzbtxpzGetParme.zbflId == null) {
            this.msgs = [];
            this.msgs.push({severity: 'error', summary: '参数缺少', detail: '请指标分类'});
        } else {
            this.HttpService.get('xtswzbfl/listSwzbpz?' + params)
                .then(res => {
                    let resList = this.DataProcessingService.replaceChildlList(res['returnObject']);
                    this.TreeTable=this.DataProcessingService.returnTreeTable(resList);
                })
                .catch(res => {
                    console.log(res);
                })
        }
    }


    showGclist() {
        if (this.showBlock == true) {
            this.showBlock = false;
        } else {
            this.showBlock = true;
        }
    }

    getGzjdId(e) {
        console.log(e);
        this.swzbtxpzGetParme.jdId = e;
        this.getList();
    }

    getProjectId(e) {
        console.log(e);
        this.swzbtxpzGetParme.ssgcdm = e;
        this.getList();
    }

    getAreaCode(e) {
        console.log(e);
        this.swzbtxpzGetParme.ssxzqhdm = e.localityCode;
        this.getList();
    }

    getZbid(e) {
        console.log(e);
        this.swzbtxpzGetParme.zbflId = e.id;
        this.getList();
    }


}

export class swzbtxpzGetParme {
    ssgcdm: string;	//所属工程代码	    是	    S000001
    ssxzqhdm: string;	//所属行政区划代码	是	    350526000000000
    zbflId: string;	//指标分类ID	    是      2F0E8D93C2B74B2AA569A961F951741D
    jdId: string;	//工作阶段ID	        是       4DDBCC17FC9348DC945B42F7C46769B0
    searchKey: string;	//用于搜索匹配字典项名称	否
}
// function getKey(a) {
//     for (var i = 0; i < a.length; i++) {
//         if (a[i].children) {
//             var data = {};
//             for (var key in a[i]) {
//
//                 if (key != 'children') {
//                     data[key] = a[i][key];
//                     delete a[i][key]
//                 }
//             }
//             a[i].data = data;
//             getKey(a[i].children);
//         } else {
//             break;
//         }
//     }
//     return a;
// }

