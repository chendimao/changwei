import {Component, OnInit, ComponentFactoryResolver, ViewChild, ViewContainerRef} from '@angular/core';
import {FgczdxpzxqComponent} from "./fgczdxpzxq.component";
import {HttpService} from "../../../service/http-service";

@Component({
    selector: 'app-fgczdxpz',
    templateUrl: './fgczdxpz.component.html',
    styleUrls: ['./fgczdxpz.component.css'],
    providers: [HttpService]
})
export class FgczdxpzComponent implements OnInit {
    cars: any;
    private gcUrl = 'gczc/allList';

    constructor(private HttpService: HttpService, private AlertModel: ComponentFactoryResolver) {
    }

    @ViewChild('pdialog', {read: ViewContainerRef}) AlertBox: ViewContainerRef;

    ngOnInit() {
        // this.HttpService.get('gczc/allList')
        //     .then(res => {
        //         console.log(res['returnObject']);
        //         this.gcList = res['returnObject'];
        //     })
    }

    addAlert() {

        let alert = this.AlertModel.resolveComponentFactory(FgczdxpzxqComponent);
        this.AlertBox.createComponent(alert);
    }


    getChildEvent(i) {
        console.log(i);
    }

}
