import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {SwzbflpzxqComponent} from "./swzbflpzxq.component";
import {HttpService} from "../../../service/http-service";

@Component({
    selector: 'app-swzbflpz',
    templateUrl: './swzbflpz.component.html',
    styleUrls: ['../swzbtxpz/swzbtxpz.component.css']
})
export class SwzbflpzComponent implements OnInit {
    showBlock: boolean = false;
    private gcList=[{}];
    private jdList=[{}];
    @ViewChild('alterRoom', {read: ViewContainerRef}) AlertBox: ViewContainerRef;

    constructor(private HttpService: HttpService, private swzbflpzxq: ComponentFactoryResolver) {
    }

    ngOnInit() {
        this.HttpService.get('gczc/allList')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/name/g, 'label');
                list = list.replace(/code/g, "value");
                this.gcList = JSON.parse(list);
                console.log(this.gcList);
            });
        this.HttpService.get('xtswzbfl/listGzjd')
            .then(res => {
                console.log(res);
                const resList = JSON.stringify(res['returnObject']);
                let list = resList.replace(/mc/g, 'label');
                list = list.replace(/id/g, "value");
                this.jdList = JSON.parse(list);
                console.log(this.jdList);
            });
    }

    showGclist() {
        if (this.showBlock == true) {
            this.showBlock = false;
        } else {
            this.showBlock = true
        }

    }

    showModule() {
        const alert = this.swzbflpzxq.resolveComponentFactory(SwzbflpzxqComponent);
        this.AlertBox.createComponent(alert);
    }
    getProjectId(e) {
        console.log(e);
        // this.swzbtxpzGetParme.ssgcdm = e;
        // this.getList();
    }
    getGzjdId(e) {
        console.log(e);
        // this.swzbtxpzGetParme.jdId = e;
        // this.getList();
    }

}
