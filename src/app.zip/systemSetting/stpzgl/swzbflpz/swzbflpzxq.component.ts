import {Component, OnInit} from '@angular/core';
import {Car} from "../../../service/car";

@Component({
    selector: 'app-swzbflpzxq',
    templateUrl: './swzbflpzxq.component.html',
    styleUrls: ['../swzbtxpz/swzbtxpz.component.css']
})
export class SwzbflpzxqComponent implements OnInit {
    display: boolean = true;
    list1: Car[];
    list2: Car[];

    constructor() {
    }

    ngOnInit() {
        this.list1 = [
            {brand: '111', year: '222', color: '222'},
            {brand: '111', year: '222', color: '222'},
            {brand: '111', year: '222', color: '222'},
            {brand: '111', year: '222', color: '222'}
        ];
        this.list2 = [];
    }

    close() {
        this.display = false;
    }

    onMoveToTarget() {
        console.log(2111);
        console.log(this.list2);
    }

    sourceSelect(e) {
        console.log(e);
    }


}
