import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {HttpService} from "../../../service/http-service";
import {ZdkglModel} from "./zdkgl.model";
import {ZdkglsjxpzxqComponent} from "./zdkglsjxpzxq.component";
import {SearchService} from "../../../service/search.service";

@Component({
    selector: 'app-zdkglxq',
    templateUrl: './zdkglsjxpz.component.html',
    styleUrls: ['./zdkgl.component.css'],
    providers: [HttpService, SearchService]
})
export class ZdkglsjxpzComponent implements OnInit {
    private display: boolean = true;
    private msgs: any;
    private selectList2 = new Object();
    private selectList1 = new Object();
    private project: ZdkglModel = new ZdkglModel();
    public info;
    private SearchList: any;
    private defaultList: any;
    private treelist: any;
    private sjMc: string;
    private zidian: ZdkglModel = new ZdkglModel();

    @ViewChild('dmroom', {read: ViewContainerRef}) dmRoom: ViewContainerRef;

    constructor(private HttpService: HttpService, private AlertBox: ComponentFactoryResolver, private searchService: SearchService) {
    }

    ngOnInit() {
        this.zidian = this.info;
        this.treelist = {
            key: 'sjId',
            id: this.zidian['id'],
            url: 'zdk/listTree'
        };


        this.sjMc = this.zidian['mc'];
        console.log(this.zidian);
        this.HttpService.get(`/zdk/list?sjId=${this.zidian['id']}&start=1&limit=10`)
            .then(res => {
                this.SearchList = res['returnObject'];
                this.defaultList = this.SearchList;
            });


        this.selectList1 = [
            {label: '虚节点', name: '虚节点', value: '0'},
            {label: '数据项', name: '数据项', value: '1'}
        ];
        this.selectList2 = [
            {label: '基本字典', name: '基本字典', value: 'JCL'},
            {label: '指标类', name: '指标类', value: 'JCL'},
            {label: '项目类', name: '项目类', value: 'JCL'},
            {label: '档案类', name: '档案类', value: 'JCL'},
        ];

    }

    close() {
        this.display = false;
    }


    showModule(i) {
        console.log(i);
        switch (i) {
            case 'add':
                const alert = this.AlertBox.resolveComponentFactory(ZdkglsjxpzxqComponent);
                const alertBox = this.dmRoom.createComponent(alert);
                alertBox.instance.parentInfo = this.zidian;
                break;
            case 'rew':
                const alert2 = this.AlertBox.resolveComponentFactory(ZdkglsjxpzxqComponent);
                const alertBox2 = this.dmRoom.createComponent(alert2);
                alertBox2.instance.parentInfo = this.zidian;
                alertBox2.instance.childInfo = this.project;
                break;
        }
    }


    search(mc) {
        this.SearchList = this.searchService.searchByRegExp(mc, this.defaultList, 'mc');
    }

    ViewDetail(i) {
        console.log(i);

        // this.HttpService.get(`/zdyy/query?id=${i}`)
        //     .then(res => {
        //         console.log(res['returnObject']);
        //         this.SearchList = res['returnObject'];
        //         console.log(this.SearchList);
        //     });
    }

    onRowSelect(event) {
        this.project = event.data;
        console.log(this.project);
    }

    getChildEvent1(e) {
        this.zidian.lx = e;
    }

    getChildEvent2(e) {
        this.zidian.zdlb = e;
    }
}
