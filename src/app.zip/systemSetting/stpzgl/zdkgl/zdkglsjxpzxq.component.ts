import {Component, OnInit} from '@angular/core';
import {HttpService} from "../../../service/http-service";
import {ZdkglModel} from "./zdkgl.model";


@Component({
    selector: 'app-zdkglsjxpzxq',
    templateUrl: './zdkglsjxpzxq.component.html',
    styleUrls: ['./zdkgl.component.css']
})
export class ZdkglsjxpzxqComponent implements OnInit {
    private display: boolean = true;
    private msgs: any;
    private selectList2 = new Object();
    private selectList1 = new Object();
    public parentInfo;
    public childInfo;
    private zidian: ZdkglModel = new ZdkglModel();


    constructor(private HttpService: HttpService) {
    }

    ngOnInit() {
        // 新增
        if (this.parentInfo != null) {
            this.zidian.sjId = this.parentInfo.id;
            this.zidian.sjlb = this.parentInfo.zdlb;
        }
        if (this.childInfo != null) {
            this.zidian = this.childInfo;
        }

        this.selectList1 = [
            {label: '数据项', name: '数据项', value: '1'}
        ];
        this.selectList2 = [
            {label: '基本字典', name: '基本字典', value: 'JCL'},
            {label: '指标类', name: '指标类', value: 'JCL'},
            {label: '项目类', name: '项目类', value: 'JCL'},
            {label: '档案类', name: '档案类', value: 'JCL'},
        ];
    }

    close() {
        this.display = false;
    }

    save(item, i) {
        console.log(this.zidian);
        console.log(i);
        this.msgs = [];
        console.log("id" in this.zidian);
        if ("id" in this.zidian) {
            // 修改
            this.HttpService.post('zdk/update', JSON.stringify(this.zidian))
                .then(res => {
                    console.log(res);
                    if (res['success'] == true) {
                        this.msgs.push({severity: 'success', summary: '填入提醒', detail: '修改成功'});
                        if (i == 'add') {
                            this.zidian = new ZdkglModel;
                        } else {
                            this.display = false;
                        }
                    } else {
                        this.msgs.push({severity: 'error', summary: '填入提醒', detail: '删除失败'});
                    }
                });
        } else {
            //保存新一项
            if (this.zidian.mc == null || this.zidian.qc == null || this.zidian.zdlb == null || this.zidian.pxh == null) {
                this.msgs.push({severity: 'error', summary: '填入提醒', detail: '有必填项未填'});
            } else {
                console.log(this.zidian);
                this.HttpService.post('zdk/save', JSON.stringify(this.zidian))
                    .then(res => {
                        console.log(res);
                        if (res['success'] == true) {
                            this.msgs.push({severity: 'success', summary: '填入提醒', detail: '新增成功'});
                            if (i == 'add') {
                                this.zidian = new ZdkglModel;
                            } else {
                                this.display = false;
                            }
                        } else {
                            this.msgs.push({severity: 'error', summary: '填入提醒', detail: res['errorMessage']});
                        }
                    });
            }
        }
    }

    zdBtn(i): void {
        switch (i) {
            case 'qc':
                console.log(this.zidian.mc);
                this.zidian.qc = this.parentInfo.qc + "-" + this.zidian.mc;
                console.log("自动生成全称");
                break;
            case 'dm':
                console.log(this.zidian.mc);
                this.zidian.dm = this.parentInfo.dm + "-" + this.zidian.xh;
                console.log("自动生成dm");
                break;
            case 'pxh':
                console.log("自动生成pxh");
                console.log(this.zidian.xh);
                break;
        }
    }

    //获取下拉列表值
    getChildEvent1(e) {
        this.zidian.lx = e;
    }

    getChildEvent2(e) {
        this.zidian.zdlb = e;
    }
}
