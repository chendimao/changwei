import {Injectable} from '@angular/core';

@Injectable()
export class TestRouterModule {
    ngOnInit() {
        console.log(11111111111);
    }


}