import {Injectable} from '@angular/core';

@Injectable()
export class DataProcessingService {

    replaceSelectList(selectList) {
        const resList = JSON.stringify(selectList);
        let list = resList.replace(/name/g, 'label');
        list = list.replace(/code/g, "value");
        list = JSON.parse(list);
        return list;
    }

    replaceChildlList(TreeTable) {
        const resList = JSON.stringify(TreeTable);
        let list = resList.replace(/childList/g, "children");
        list = JSON.parse(list);
        return list;
    }

    returnTreeTable(TreeTable) {
        for (var i = 0; i < TreeTable.length; i++) {
            if (TreeTable[i].children) {
                var data = {};
                for (var key in TreeTable[i]) {
                    if (key != 'children') {
                        data[key] = TreeTable[i][key];
                        delete TreeTable[i][key];
                    }

                }
                TreeTable[i].data = data;
                this.returnTreeTable(TreeTable[i].children);
            } else {
                var data = {};
                for (var key in TreeTable[i]) {
                    if (key != 'children') {
                        data[key] = TreeTable[i][key];
                        delete TreeTable[i][key];
                    }
                }
                TreeTable[i].data = data;
                break;
            }
        }
        return TreeTable;
    }
}
