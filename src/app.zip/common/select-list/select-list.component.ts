import {Component, OnInit, Input, Output, EventEmitter, AfterViewInit} from '@angular/core';
import {HttpService} from "../../service/http-service";


@Component({
    selector: 'app-select-list',
    templateUrl: './select-list.component.html',
    styleUrls: ['./select-list.component.css'],
    providers: [HttpService]
})
export class SelectListComponent implements OnInit {
    @Input() values = new Array;
    @Input() isEdit;
    @Input() width;
    @Input() search;
    @Output() SelectModel = new EventEmitter;
    private reswidth;
    private isdisabled: boolean = false;

    constructor(private HttpService: HttpService) {

    }

    ngOnInit() {
        this.reswidth = `calc(100% - ${this.width}px)`;
    }

    ngOnChanges() {
        if (this.values != undefined) {
            this.SelectModel.emit(this.values[0].value);
            console.log(this.SelectModel);
            if (this.values.length == 1) {
                this.isdisabled = true;
            } else {
                this.isdisabled = false;
            }
        }

    }

    OutPutValue(value) {
        this.SelectModel.emit(value);
    }

}
