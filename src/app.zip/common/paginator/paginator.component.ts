import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {HttpService} from "../../service/http-service";

@Component({
    selector: 'app-paginator',
    templateUrl: './paginator.component.html',
    styleUrls: ['./paginator.component.css'],
    providers: [HttpService]
})
export class PaginatorUserComponent implements OnInit {
    @Input() totalPage;
    @Input() count;
    @Input() url;
    @Output() pageSelect = new EventEmitter();

    constructor(private HttpService: HttpService) {
    }

    ngOnInit() {
        console.log(this.url);

    }

    paginate(value) {
        console.log(value);
        console.log(`${this.url}?start=${value.first + 1}&limit=${value.rows}`);
        this.HttpService.get(`${this.url}?start=${value.first + 1}&limit=${value.rows}`)
            .then(res => {
                this.pageSelect.emit(res);
            });
    }

}
