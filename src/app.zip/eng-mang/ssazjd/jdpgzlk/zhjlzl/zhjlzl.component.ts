import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zhjlzl',
  templateUrl: './zhjlzl.component.html',
  styleUrls: ['../jdpgzlk.component.css']
})
export class  ZhjlzlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
