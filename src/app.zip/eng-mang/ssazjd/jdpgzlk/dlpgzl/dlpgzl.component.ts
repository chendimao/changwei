import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dlpgzl',
  templateUrl: './dlpgzl.component.html',
    styleUrls: ['../jdpgzlk.component.css']
})
export class  DlpgzlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
