import {KxxyjbgjdComponent} from './kxxyjbgjd.component';


import {JmhComponent} from './swzb/jmh/jmh.component';


import {GhzbComponent} from './ghzb/ghzb.component';

import {ScazrkComponent} from './ghzb/ncymaz/scazrk/scazrk.component';
import {GyqyclComponent} from './ghzb/gyqycl/gyqycl.component';
import {RoadComponent} from './ghzb/zyxmcl/road/road.component';
import {DecorationComponent} from './swzb/jmh/swzb-person/hjbxx/decoration/decoration.component';
import {FsssComponent} from './swzb/jmh/swzb-person/hjbxx/fsss/fsss.component';
import {GraveComponent} from './swzb/jmh/swzb-person/hjbxx/grave/grave.component';
import {HousesComponent} from './swzb/jmh/swzb-person/hjbxx/houses/houses.component';
import {LandComponent} from './swzb/jmh/swzb-person/hjbxx/land/land.component';
import {LandOtherComponent} from './swzb/jmh/swzb-person/hjbxx/land-other/land-other.component';
import {PersonComponent} from './swzb/jmh/swzb-person/hjbxx/person/person.component';
import {TreesComponent} from './swzb/jmh/swzb-person/hjbxx/trees/trees.component';
import {WaterComponent} from './swzb/jmh/swzb-person/hjbxx/water/water.component';
import {TzgsComponent} from "./tzgs/tzgs.component";
import { JtjjzzComponent } from "./swzb/jtjjzz/jtjjzz.component";

export const KxxyjbgjdRoutingModule = [
    {
        path: '',
        component: KxxyjbgjdComponent,
        children: [
            {
                path: 'swzb/:item',
                component: JmhComponent,
                children: [
                    {path: '', redirectTo: 'person', pathMatch: 'full'},
                    {path: 'decoration', component: DecorationComponent},
                    {path: 'fsss', component: FsssComponent},
                    {path: 'grave', component: GraveComponent},
                    {path: 'houses', component: HousesComponent},
                    {path: 'land', component: LandComponent},
                    {path: 'landOther', component: LandOtherComponent},
                    {path: 'person', component: PersonComponent},
                    {path: 'trees', component: TreesComponent},
                    {path: 'water', component: WaterComponent},
                    {path: 'water', component: WaterComponent},
                    {}
                ]
            },
            {
                path: 'swzb/jtjjzz',
                component: JtjjzzComponent,
                children: [
                    {path: '', redirectTo: 'person', pathMatch: 'full'},
                    {path: 'decoration', component: DecorationComponent},
                    {path: 'fsss', component: FsssComponent},
                    {path: 'grave', component: GraveComponent},
                    {path: 'houses', component: HousesComponent},
                    {path: 'land', component: LandComponent},
                    {path: 'landOther', component: LandOtherComponent},
                    {path: 'person', component: PersonComponent},
                    {path: 'trees', component: TreesComponent},
                    {path: 'water', component: WaterComponent},
                ]
            },
            {
                path: 'ghzb',
                component: GhzbComponent,
                children: [
                    {path: 'ncymaz/scazrk', component: ScazrkComponent},
                    {path: 'zyxmcl/road', component: RoadComponent},
                ]

            },
            {path: 'tzgs/tzgs', component: TzgsComponent}
        ]

    },
    {
        path: '',

    }
]