import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule} from '@angular/router';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import {
    BreadcrumbModule,
    PanelModule,
    DropdownModule,
    TabViewModule,
    CheckboxModule,
    AccordionModule,
    CalendarModule,
    FileUploadModule,
    PaginatorModule,
    DialogModule,
    SelectButtonModule,
    FieldsetModule,
    DataTableModule,
    SharedModule,
    GrowlModule
} from 'primeng/primeng';
import {ValuChangeService} from "../../service/valuChange.service";
import {CardReformPipe} from "../../pipe/card-reform.pipe";
import {UserCommonModule} from '../../common/UserCommon.module';

import {KxxyjbgjdRoutingModule} from './kxxyjbgjd-routing.module';
import {KxxyjbgjdComponent} from './kxxyjbgjd.component';
import {JmhComponent} from './swzb/jmh/jmh.component';
import {NcymazComponent} from './ghzb/ncymaz/ncymaz.component';
import {GhzbComponent} from './ghzb/ghzb.component';
import {ScazrkComponent} from './ghzb/ncymaz/scazrk/scazrk.component';
import {GyqyclComponent} from './ghzb/gyqycl/gyqycl.component';
import {RoadComponent} from './ghzb/zyxmcl/road/road.component';
import {SwzbPersonComponent} from './swzb/jmh/swzb-person/swzb-person.component';
import {DecorationComponent} from './swzb/jmh/swzb-person/hjbxx/decoration/decoration.component';
import {FsssComponent} from './swzb/jmh/swzb-person/hjbxx/fsss/fsss.component';
import {GraveComponent} from './swzb/jmh/swzb-person/hjbxx/grave/grave.component';
import {HousesComponent} from './swzb/jmh/swzb-person/hjbxx/houses/houses.component';
import {LandComponent} from './swzb/jmh/swzb-person/hjbxx/land/land.component';
import {LandOtherComponent} from './swzb/jmh/swzb-person/hjbxx/land-other/land-other.component';
import {PersonComponent} from './swzb/jmh/swzb-person/hjbxx/person/person.component';
import {TreesComponent} from './swzb/jmh/swzb-person/hjbxx/trees/trees.component';
import {WaterComponent} from './swzb/jmh/swzb-person/hjbxx/water/water.component';
import {TzgsComponent} from "./tzgs/tzgs.component";
import {JmhQueryComponent} from "./swzb/jmh/jmh_query.component";
import {JmhFjViewComponent} from "./swzb/jmh/jmh_fj_view.component";
import {JmhMangComponent} from "./swzb/jmh/jmh_fj_mang.component";
import {JmhfjmangsecComponent} from "./swzb/jmh/jmh_fj_mangsec.component";
import { JtjjzzComponent } from './swzb/jtjjzz/jtjjzz.component';

@NgModule({
    declarations: [
        CardReformPipe,
        TzgsComponent,
        NcymazComponent,
        GhzbComponent,

        JmhComponent,
        ScazrkComponent,
        KxxyjbgjdComponent,
        GyqyclComponent,
        RoadComponent,
        SwzbPersonComponent,
        DecorationComponent,
        FsssComponent,
        GraveComponent,
        HousesComponent,
        LandComponent,
        LandOtherComponent,
        PersonComponent,
        TreesComponent,
        WaterComponent,
        JmhFjViewComponent,
        JmhQueryComponent,
        JmhMangComponent,
        JmhfjmangsecComponent,
        JtjjzzComponent
    ],

    imports: [
        PdfViewerModule,
        BreadcrumbModule,
        PanelModule,
        DropdownModule,
        CommonModule,
        UserCommonModule,
        CheckboxModule,
        DataTableModule,
        SharedModule,
        FieldsetModule,
        SelectButtonModule,
        DialogModule,
        PaginatorModule,
        FileUploadModule,
        HttpModule,
        FormsModule,
        TabViewModule,
        GrowlModule,
        AccordionModule,
        CalendarModule,
        RouterModule.forChild(KxxyjbgjdRoutingModule)
    ],
    entryComponents: [JmhQueryComponent, JmhfjmangsecComponent, JmhFjViewComponent, JmhMangComponent, SwzbPersonComponent],
    providers: [ValuChangeService],
})
export class KxxyjbgjdModule {
}
