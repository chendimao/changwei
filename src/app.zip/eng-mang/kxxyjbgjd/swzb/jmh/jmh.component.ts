import {Component, OnInit, ViewChild, ViewContainerRef, ComponentFactoryResolver} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {flyIn} from "../../../../animations/fly-in";
import {JmhQueryComponent} from "./jmh_query.component";
import {JmhFjViewComponent} from "./jmh_fj_view.component";
import {JmhMangComponent} from "./jmh_fj_mang.component";
import {SwzbPersonComponent} from "./swzb-person/swzb-person.component";

@Component({
    selector: 'app-jmh',
    templateUrl: './jmh.component.html',
    styleUrls: ['./jmh.component.css'],
    animations: [flyIn]
})
export class JmhComponent implements OnInit {
    private id: number;
    private msgs: any;
    private projectId: number;
    public persionList: any;
    public selectedHu: any;

    private totalPage: number;
    private count: number;


    @ViewChild('modelRoom', {read: ViewContainerRef}) ModelRoom: ViewContainerRef;

    // 加的加载
    isShowRight: boolean = false;
    defaultShow: boolean = true;

    moduleStyle: any;

    openModal(name) {
        this.ModelRoom.clear();
        switch (name) {
            case 'query':
                const query = this.AlertModel.resolveComponentFactory(JmhQueryComponent);
                this.ModelRoom.createComponent(query);
                break;
            case 'addPerson':
                const person = this.AlertModel.resolveComponentFactory(SwzbPersonComponent);
                const perModel = this.ModelRoom.createComponent(person);
                perModel.instance.huId = "啊啊啊啊啊";
                break;


            case 'fj_view':
                const fjView = this.AlertModel.resolveComponentFactory(JmhFjViewComponent);
                this.ModelRoom.createComponent(fjView);
                break;
            case 'fj_mang':
                const fjMang = this.AlertModel.resolveComponentFactory(JmhMangComponent);
                this.ModelRoom.createComponent(fjMang);
                break;
        }
    }

    constructor(private AlertModel: ComponentFactoryResolver, private route: ActivatedRoute) {
    }

    ngOnInit() {
        console.log(this.route.params.subscribe(res => {
            this.projectId = res['id'];
            console.log(res);
        }));

        // this.HttpService.get('gczc/list?start=1&limit=10')
        //     .then(res => {
        //         this.totalPage = res['totalPage'];
        //            this.count=res['count'];
        //         this.cars = res['returnObject'];
        //     });
        this.persionList = persionList;
    }

    // queryList(e) {
    //     let start = e.first;
    //     console.log(start);
    //     this.HttpService.get(`gczc/list?start=${start}&limit=10`)
    //         .then(res => {
    //             this.cars = res['returnObject'];
    //         });
    //
    // }

    onRowSelect(list) {

        this.id = list['id'];
        this.selectedHu = list;
        console.log(this.id);
    }


    getEvent(event) {
        this.isShowRight = event;
        this.defaultShow = false;
    }
}


const persionList: any = [
    {
        id: 1,
        cid: '205202011001',
        name: '蔡国成',
        area: '福建省泉州市安溪县白濑乡长基村',
        fanwei: '水库淹没影响区-淹没区',
        type: '农村部分',
        kong: '是',
        xianwai: '否',
        remark: '无'
    },
    {
        id: 2,
        cid: '205202011002',
        name: '李应春',
        area: '福建省泉州市安溪县白濑乡长基村',
        fanwei: '水库淹没影响区-淹没区',
        type: '农村部分',
        kong: '是',
        xianwai: '否',
        remark: '无'
    },
    {
        id: 3,
        cid: '205202011003',
        name: '蔡加明',
        area: '福建省泉州市安溪县白濑乡长基村',
        fanwei: '水库淹没影响区-淹没区',
        type: '农村部分',
        kong: '是',
        xianwai: '否',
        remark: '无'
    },
    {
        id: 4,
        cid: '205202011004',
        name: '文秀全',
        area: '福建省泉州市安溪县白濑乡长基村',
        fanwei: '水库淹没影响区-淹没区',
        type: '农村部分',
        kong: '是',
        xianwai: '否',
        remark: '无'
    },

];
