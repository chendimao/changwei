import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, ParamMap} from '@angular/router';
import {MenuItem, Message, SelectItem,} from 'primeng/primeng';
import {flyIn} from "../../../../../animations/fly-in";
import {HjbxxModel} from "./Hjbxx.model";
import {MessageService} from 'primeng/components/common/messageservice';

@Component({
    selector: 'app-swzb-person',
    templateUrl: './swzb-person.component.html',
    styleUrls: ['./swzb-person.component.css'],
    animations: [flyIn]
})
export class SwzbPersonComponent implements OnInit {
    private selectList = new Array;
    public hjbxx = new HjbxxModel;
    public huId: string;
    msgs: Message[] = [];
    Breadcrumb: MenuItem[];

    types1: SelectItem[];
    types2: SelectItem[];
    navList = new Array;
    public showqqq: boolean = true;
    isShowDcfw: boolean = false;
    moreInput: boolean = false;
    moreText: string = "显示更多内容";
    private whetherDisabled: boolean;
    public selectedType1: string;
    public selectedType2: string;
    public isShowArea: boolean = false;
    ssxzqhdm: string;

    public isDisabled: boolean = true;


    constructor(private route: ActivatedRoute, private router: Router) {
        this.types1 = [];
        this.types1.push({label: '是', value: 'yes'});
        this.types1.push({label: '否', value: 'no'});
        this.types2 = [];
        this.types2.push({label: '是', value: 'yes'});
        this.types2.push({label: '否', value: 'no'});
    }

    ngOnInit() {
        this.hjbxx.zydldm = "null";
        console.log(this.huId);
        console.log(this.route.queryParams['value']);
        if (this.route.queryParams['value'].way == '1') {
            this.whetherDisabled = true;
        }
        this.selectedType1 = 'yes';
        this.selectedType2 = 'yes';

        this.navList = navList;

        this.selectList = [
            {label: '农村部分', name: '农村部分', value: '0'},
            {label: '县城部分', name: '县城部分', value: '1'},
            {label: '集镇部分', name: '集镇部分', value: '2'},
        ];
    }

    selectedTypea(): void {
        console.log(this.selectedType1);
    }


    showAreaBlock(): void {
        if (this.isShowArea) {
            this.isShowArea = false;
        } else {
            this.isShowArea = true;
        }
    }

    getChildEvent(index) {
        this.hjbxx.zydldm = index;
    }

    showTypeBlock() {
        if (this.isShowDcfw) {
            this.isShowDcfw = false;
        } else {
            this.isShowDcfw = true;
        }
    }


    showMoreInput() {

        if (this.moreInput) {
            this.moreInput = false;
            this.moreText = "显示更多内容";
        } else {
            this.moreInput = true;
            this.moreText = "隐藏更多内容";
        }
    }

    close() {
        this.showqqq = false;
    }

    saveRouter(url) {
        this.router.navigate([url], {relativeTo: this.route});
    }

    show(info: object): void {
        console.log(sessionStorage['person']);
        for (let i in info) {
            if (info[i] == "") {
                for (let f in this.hjbxx) {
                    if (i == f) {
                        console.log(this.hjbxx[f]);
                        this.msgs = [];
                        this.msgs.push({severity: 'error', summary: '填入提醒', detail: this.hjbxx[f] + ' 必填'});
                    }
                }
            }
        }
    }
}


const hjbxx = {
    ssxtdm: '所属系统',
    ssgcdm: '所属工程',
    jddm: '阶段',
    ssxzqhdm: '所属行政区划',
    zydldm: '专业大类',
    dcfwdm: '调查范围',
    hlbdm: '户类型',
    hzxm: '户主姓名',
    dabh: '档案编号',
    hs: '户数',
    sfkgh: '是否空挂户',

};

const navList = [
    {path: 'person', name: '人口'}, {path: 'houses', name: '房屋'}, {path: 'decoration', name: '装修'},
    {path: 'fsss', name: '附属设施'}, {path: 'land', name: '土地'},
    {path: 'landOther', name: '土地附着物'}, {path: 'trees', name: '零星树木'},
    {path: 'water', name: '小型水利水电'}, {path: 'grave', name: '坟墓'},
];


