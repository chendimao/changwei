import {Component, OnInit} from '@angular/core';
import {flyIn} from "../../../../animations/fly-in";

@Component({
    selector: 'app-jtjjzz',
    templateUrl: '../jmh/jmh.component.html',
    styleUrls: ['../jmh/jmh.component.css'],
    animations: [flyIn]
})
export class JtjjzzComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
    }

}
